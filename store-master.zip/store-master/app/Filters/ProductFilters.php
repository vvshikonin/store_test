<?php

namespace App\Filters;

/**
 * Не реализован (заглушка).
 */
class ProductFilters extends Filter
{}
