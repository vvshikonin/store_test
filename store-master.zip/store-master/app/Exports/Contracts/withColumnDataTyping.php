<?php

namespace App\Exports\Contracts;

interface withColumnDataTyping
{
    function columnDataTyping();
}
