<?php

namespace App\Exports\Contracts;

interface withColumnHozirontalAlignment
{
    function columnHorizontalAlignment();
}
